package com.example.mariokartproyect

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.mariokartproyect.navigation.AppScreens
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController

@Composable
fun MainScreen(navController: NavHostController) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Imagen de fondo
        Image(
            painter = painterResource(id = R.drawable.fondopantalla),
            contentDescription = "Fondo",
            modifier = Modifier.fillMaxSize()
        )

        // Contenido principal
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Título en la parte superior
            Text(
                text = "Mario Bros",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 32.dp)
            )

            // Espacio flexible para centrar los botones
            Spacer(modifier = Modifier.weight(1f))

            // Botones en la parte inferior
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(onClick = { navController.navigate(AppScreens.GameScreen.route) }) {
                    Text(text = "Jugar")
                }
                Button(onClick = { salirDeLaApp() }) {
                    Text(text = "Salir")
                }
            }

            // Espacio adicional en la parte inferior
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

fun salirDeLaApp() {
    android.os.Process.killProcess(android.os.Process.myPid())
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    val navController = rememberNavController()
    MainScreen(navController = navController)
}

fun salir() {
    // Cerrar la aplicación
    android.os.Process.killProcess(android.os.Process.myPid())
}