package com.example.mariokartproyect

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.input.key.*

@Composable
fun GameScreen(navController: NavController) {
    var progressP1 by remember { mutableStateOf(0f) } // Progreso de P1
    var progressP2 by remember { mutableStateOf(0f) } // Progreso de P2
    var winner by remember { mutableStateOf<String?>(null) } // Ganador

    if (winner != null) {
        AlertDialog(
            onDismissRequest = { /* No hace nada */ },
            title = { Text("¡Ganador!") },
            text = { Text("$winner ha ganado!") },
            confirmButton = {
                Button(onClick = {
                    navController.navigate("main_screen") // Navegar al menú
                }) {
                    Text("Volver al Menú")
                }
            }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .focusable() // Permitir que el Box reciba el foco
            .onKeyEvent { event ->
                when (event.key) {
                    Key.A -> { // Tecla 'A'
                        // Aumentar el progreso de P1
                        progressP1 = (progressP1 + 0.01f).coerceAtMost(1f)
                        if (progressP1 >= 1f && winner == null) {
                            winner = "P1"
                        }
                        true
                    }
                    Key.J -> { // Tecla 'J'
                        // Aumentar el progreso de P2
                        progressP2 = (progressP2 + 0.01f).coerceAtMost(1f)
                        if (progressP2 >= 1f && winner == null) {
                            winner = "P2"
                        }
                        true
                    }
                    else -> false
                }
            }
    ) {
        // Imagen de fondo
        Image(
            painter = painterResource(id = R.drawable.fondopantalla), // Reemplaza con tu imagen
            contentDescription = null,
            modifier = Modifier.fillMaxSize()
        )

        // Contenido del juego
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top // Asegura que el texto esté en la parte superior
        ) {
            Text(
                text = "¡Juego en Progreso!",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp)
            )
        }

        // Barras de progreso y botones en la parte inferior
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            // Barra P1
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = "P1",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 16.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp)
                        .background(color = Color.Red)
                        .border(width = 2.dp, color = Color.Black)
                ) {
                    // Barra de progreso
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progressP1) // Progreso de la barra
                            .background(color = Color.Green) // Color de la barra de progreso
                    )
                }
            }

            // Barra P2
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = "P2",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 16.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp)
                        .background(color = Color.Blue)
                        .border(width = 2.dp, color = Color.Black)
                ) {
                    // Barra de progreso
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progressP2) // Progreso de la barra
                            .background(color = Color.Yellow) // Color de la barra de progreso
                    )
                }
            }
        }
    }
}
